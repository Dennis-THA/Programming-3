#ifndef _HR_H
#define _HR_H

#include "Person.h"
#include "Employee.h"
#include "Manager.h"
#include "Director.h"

#endif